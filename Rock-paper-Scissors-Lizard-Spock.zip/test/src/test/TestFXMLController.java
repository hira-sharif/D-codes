
package test;

import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class TestFXMLController implements Initializable {

    @FXML
    private Button btnRock;
    @FXML
    private Button btnPaper;
    @FXML
    private Button btnScissors;
    @FXML
    private Button btnLizard;
    @FXML
    private Button btnSpock;
    @FXML
    private Label lblOutput;
    @FXML
    private ImageView computer;
    @FXML
    private ImageView player;

    private static final String ROCK="rock";
    private static final String PAPER="paper";
    private static final String SCISSORS="scissors";
    private static final String LIZARD="lizard";
    private static final String SPOCK="spock";
    private Image imageComputer,imagePlayer; 
    int r;
    Random random = new Random();
    String computerchoice;
    
     private void Computer(){
        r = 1 + random.nextInt()%5; //1 = rock, 2 = paper, 3 = scissor, 4 = lizard, 5 = spock
        r = Math.abs(r);
        switch(r){
            case 1:
                imageComputer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\rock.png");
            computerchoice = ROCK;
                break;
            case 2:
                imageComputer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\paper.png");
            computerchoice = PAPER;
                break;
            case 3: 
                imageComputer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\scissors.png");
            computerchoice = SCISSORS;
                break;
            case 4: 
                imageComputer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\lizard.png");
            computerchoice = LIZARD;
                break;
            case 5: 
                imageComputer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\spock.png");
            computerchoice = SPOCK;
                break;
        }
        computer.setImage(imageComputer);
    }
     
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void HandleRock(ActionEvent event)
    {
    Computer();
    imagePlayer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\rock.png");
    switch(computerchoice){
            case ROCK: 
                lblOutput.setText("It's a tie ! \n Computer also chose Rock.");
                break;
            case PAPER:
                lblOutput.setText("You lose ! \n Paper covers Rock");
                break;
            case SCISSORS:
                lblOutput.setText( "You won ! \n Rock crushes Scissor.");
                break;
            case LIZARD:
                lblOutput.setText("You won ! \n Rock crushes Lizard.");
                break;
            case SPOCK:
                lblOutput.setText("You lose ! \n Spock vaporizes Rock.");
                break;
        }
    
        player.setImage(imagePlayer);
    }

    @FXML
    private void HandlePaper(ActionEvent event) 
    {
        imagePlayer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\paper.png");
         Computer();
         switch(computerchoice){

            case ROCK: 
                lblOutput.setText( "You won ! \n Paper covers Rock.");
                break;
            case PAPER:
                lblOutput.setText("It's a tie !\n Computer also chose Paper.");
                break;
            case SCISSORS:
                lblOutput.setText( "You lose ! \n Scissor cuts Paper.");
                break;
            case LIZARD:
                 lblOutput.setText( "You lose !\n Lizard eats Paper");
                break;
            case SPOCK:
                lblOutput.setText( "You won !\n Paper disproves Spock.");
                break;
        }
      player.setImage(imagePlayer);
    }

    @FXML
    private void HandleScissors(ActionEvent event) 
    {
        imagePlayer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\scissors.png");
        Computer();
         switch(computerchoice){
            case ROCK: 
                lblOutput.setText("You lose ! \n Rock crushes Scissor.");
                break;
            case PAPER:
                lblOutput.setText("You won !\n Scissor cuts Paper.");
                break;
            case SCISSORS:
                lblOutput.setText( "It's a tie !\n Computer also chose Scissor.");
                break;
            case LIZARD:
                lblOutput.setText("You won !\n Scissor decapitates Lizard.");
                break;
            case SPOCK:
                lblOutput.setText("You lose !\n Spock smashes Scissor.");
                break;
        }
         player.setImage(imagePlayer);
    }

    @FXML
    private void HandleLizard(ActionEvent event) 
    {
        imagePlayer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\lizard.png");
        Computer();
         switch(computerchoice){
            
            case ROCK: 
                lblOutput.setText("You lose !\n Rock crushes Lizard");
                break;
            case PAPER:
                lblOutput.setText( "You lose !\n Scissor decapitates Lizard.");
                break;
            case SCISSORS:
                lblOutput.setText( "You won ! \n Lizard eats Paper.");
                break;
            case LIZARD:
                lblOutput.setText( "It's a tie !\n Computer also chose Lizard.");
                break;
            case SPOCK:
                lblOutput.setText("You won ! \n Lizard poisons Spock.");
                break;
        }
         player.setImage(imagePlayer);
    }

    @FXML
    private void HandleSpock(ActionEvent event) 
    {
        imagePlayer=new Image("D:\\courses\\CIS_296\\test\\src\\images\\spock.png");
        Computer();
        switch(computerchoice){
            
            case ROCK: 
                lblOutput.setText( "You won ! \n Spock vaporizes Rock.");
                break;
            case PAPER:
                lblOutput.setText( "You lose !\n Paper disproves Spock.");
                break;
            case SCISSORS:
                lblOutput.setText( "You won ! \n Spock smashes Scissor.");
                break;
            case LIZARD:
                lblOutput.setText( "You lose ! \n Lizard poisons Spock");
                break;
            case SPOCK:
                lblOutput.setText( "It's a tie ! \n Computer also chose Spock");
                break;
        }
        player.setImage(imagePlayer);
    }
    
}
    
