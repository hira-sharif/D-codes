
#include <iostream>
#include<string>
#include<iomanip>
#include<math.h>
#include<stdlib.h>
#include<fstream>
using namespace std;


//adding output file
ofstream file("D:/HIRASHARIF/HiraSharif_CIS400_A3/output.txt");
// global variables display and result
string display="\t->";
double result = 0;

// calculator
float calculator(float a, float b, char o)
{
    double r = 0;
    if (o == '+')
        r = a + b;
    else if (o == '-')
        r = a - b;
    else if (o == '*')
        r = a * b;
    else
        r = a / b;
    return r;
}

//<operator> 
bool operator1(char op)
{
    if (op == '+' || op == '-' || op=='*' || op=='/')
        return true;
    else
    {
        return false;
    }
}

//<sign> 
bool sign(char sign1)
{
    if (sign1 == '+' || sign1 == '-')
    {
        return true;
    }
    else
    {
        return false;
    }
}
//<digit> 
bool digit(char digit1)
{
    if (digit1 == '0' || digit1 == '1' || digit1 == '2' || digit1 == '3' || digit1 == '4' || digit1 == '5' || digit1 == '6' || digit1 == '7' || digit1 == '8' || digit1 == '9')
    {
        return true;
    }
    else
    {
        return false;
    }
}
// <unsigned>
bool unsign(string unsign1)
{
    bool x = false;
    file << display << " <digit>{<digit>}[.<unsigned>][<operator><expression>] =" << endl;
    if (unsign1.length() == 0)
    {
        file << "Error: " << endl;
        file << "Rule voilated:\t\t <digit> -> 0|1|2|3|4|5|6|7|8|9" << endl;
        return false;
    }
    //  <digit> {<digit>} 
    for (int i = 0; i < unsign1.length(); i++)
    {
        x = digit(unsign1.at(i));
        //if not digit
        if (x == false)
        {

            file << "Error: \"" << unsign1.at(i) << "\" is not a <digit>." << endl;
            file << "Rule voilated:\t\t <digit> -> 0|1|2|3|4|5|6|7|8|9" << endl;
            return false;
        }
    }
    return x;
}
// <value> 
bool value(string value1)
{
    string dig,str;
    int found;
    bool usign;
        //  sign as first element
        found = value1.find('.');
        if (found != string::npos && found != (value1.length() - 1))
        {
            
            if (sign(value1.at(0)))
            {
                file << display << " <sign><unsigned>[.<unsigned>][<operator><expression>] =" << endl;
                display = display + " " + value1.at(0);
                file << display << " <unsigned>[.<unsigned>][<operator><expression>] =" << endl;
                dig = value1.substr(1, found - 1);
            }
            else
            {
                file << display << " [<sign>]<unsigned>[.<unsigned>][<operator><expression>] =" << endl;
                file << display << " <unsigned>[.<unsigned>][<operator><expression>] =" << endl;
                dig = value1.substr(0, found);
            }
            found = true;
            // if <unsign> before point
            if (unsign(dig))
            {
                display = display + " " + dig;
                file << display << " [.<unsigned>][<operator><expression>] =" << endl;
                // if <unsign> after point
                if (unsign(value1.substr(found + 1)))
                {
                    display += " ." + value1.substr(found + 1);
                    file << display << " [<operator><expression>] =" << endl;
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
                return false;
        }
        else
        {
            if (sign(value1.at(0)))
            {
                usign = unsign(value1.substr(1));
                str = value1.substr(1);
            }
            else
            {
                usign = unsign(value1);
                str = value1;

            }
            if (usign)
            {
                display += " " + str;
                file << display << " [<operator><expression>] =" << endl;
                return true;
            }
            else
                return false;
        }
}
//<expression>
bool expression(string exp)
{
    char o = '?';
    float op1 = 0, op2 = 0;
    bool x;
    string val;
    int count = std::count(exp.begin(), exp.end(), '.');
    if (count > 1)
    {
        file << "Error:" << endl;
        file << "Rule voilated:\t\t you can only use 1 point for [.<unsigned>]" << endl;
        return false;
    }
    file << display << " <value>[<operator><expression>] =" << endl;
    for (int j = 0; j < exp.length(); j++)
    {

        //neither digit not point
        if (!digit(exp.at(j)) && exp.at(j) != '.')
        {
            // first element
            if (j == 0)
            {
                //  <sign>
                if (sign(exp.at(j)))
                {
                    val += exp.at(j);
                }
                else
                {
                    file << "Error: \"" << exp.at(j) << "\" is not a <digit>." << endl;
                    file << "Rule voilated:\t\t <digit> -> 0|1|2|3|4|5|6|7|8|9" << endl;
                    return false;
                }
            }
            // last element
            else if (j == exp.length() - 1)
            {
                file << "Error: \"" << exp.at(j) << "\" is not an <operator>." << endl;
                file << "Rule voilated:\t\t <operator> -> +|-|*|/" << endl;
                return false;
            }
            // if privious was <operator> check it is <sign> 
            else if (operator1(exp.at(j - 1)))
            {
                if (operator1(exp.at(0)) && operator1(exp.at(1)))
                {
                    file << "Error: \"" << exp.at(j) << "\" is not a <digit>." << endl;
                    file << "Rule voilated:\t\t <digit> -> 0|1|2|3|4|5|6|7|8|9" << endl;
                    return false;
                }
                else if (sign(exp.at(j)))
                {
                    // add <sign>
                    val += exp.at(j);
                }
                else
                {
                    file << "Error: \"" << exp.at(j) << "\" is not a <sign>." << endl;
                    file << "Rule voilated:\t\t <sign> -> +|-" << endl;
                    return false;
                }
            }
            //  <operator> and check if the substring before it is <value>
            else
            {
                if (operator1(exp.at(j)))
                {

                    x = value(val);
                    // if operator is more than once
                    if (o != '?')
                    {

                        op2 = stof(val);
                        result = calculator(op1, op2, o);
                        o = exp.at(j);
                        op1 = result;
                    }
                    // if operator comes first time
                    else
                    {
                        op1 = stof(val);
                        o = exp.at(j);
                    }
                    file << display << " <operator><expression> =" << endl;
                    display = display + " " + exp.at(j);
                    file << display << " <expression> =" << endl;
                }
                else
                {
                    file << "Error: \"" << exp.at(j) << "\" is not an <operator>." << endl;
                    file << "Rule voilated:\t\t <operator> -> +|-|*|/" << endl;
                    return false;
                }
                val = "";
            }
        }
        // if either digit or point add into substring.
        else
        {
            val += exp.at(j);
        }
    }
    file << display << " <value>[<operator><expression>] =" << endl;
    //if there is neither [<sign>] nor [.<unsigned>]
    x = value(val);
    if (x == true)
    {
        if (o != '?')
        {
            op2 = stof(val);
            result = calculator(op1, op2, o);
        }
        else
        {
            result =stof(val);
        }
        cout << "result " << result;
        display += " =";
        file << display << endl;
    }
    return x;
}

int main()
{
    char ch;
    string language="";
    bool a= true;

    if (file.is_open())
    {
        cout << "please enter the input string:\n\t(end the string with '=')" << endl;
        while (cin>>ch)
        {
                language += ch;
                if (ch == '=')
                    goto lable;
        }
    lable:
        if (language.at(0) == '=')
        {
            cout << "EMPTY STRING! followed by '='" << endl;
        }
        else
        {
            language.pop_back();
            file << endl << "User input:" << "\t" << language << "=" << endl;
            file << endl << "derivaion:" << endl << "<calculation> ->  <expression> = " << endl;
            a = expression(language);
            if (a == true)
                file << "Result: " << language << "=" << result << endl;
            else
                file << "Result: " << language << "= \"INVALID CALCULATION!\"" << endl;
        }

        
    }
    else
        cout << "can not open file!" << endl;
    file.close();
}
